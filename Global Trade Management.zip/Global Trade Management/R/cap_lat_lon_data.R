#' @title cap_lat_lon
#'
#' @description Dataframe of capital city latitude and longitude coordinates
#' @name cap_lat_lon
#' @docType data
#' @usage cap_lat_lon
#' @keywords datasets
NULL
